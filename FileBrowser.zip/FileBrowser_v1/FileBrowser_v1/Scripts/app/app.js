﻿(function (angular) {
    'use strict';
    angular.module('app', ['home', 'app.routes', 'app.services']);
    //    .controller('appCtrl', ['$scope', '$rootScope', '$location',
    //function ($scope, $rootScope, $location) {
    //    debugger;
    //}])
    ;
})(window.angular);